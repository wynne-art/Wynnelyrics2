#!/usr/bin/env bash
# Compiles and runs the Minecraft-independent self tests with a plain JDK 21.
set -e
cd "$(dirname "$0")/../.."
OUT=$(mktemp -d)
B=src/main/java/com/wynlyrics
JAVAC="javac"; command -v javac >/dev/null || JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"
$JAVAC -d "$OUT" $B/util/*.java $B/lyrics/LrcLine.java $B/lyrics/LrcData.java $B/lyrics/LrcParser.java \
  $B/lyrics/LyricSource.java $B/lyrics/LyricView.java $B/lyrics/SampleSource.java $B/spotify/Pkce.java tools/selftest/SelfTest.java
java -cp "$OUT" SelfTest
