package com.wynlyrics.music;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wynlyrics.WynLyricsClient;
import com.wynlyrics.config.WynConfig;
import com.wynlyrics.lyrics.FabricPaths;
import com.wynlyrics.lyrics.LrcPlayer;
import com.wynlyrics.spotify.Http;
import com.wynlyrics.spotify.SpotifyAuth;
import com.wynlyrics.spotify.SpotifyClient;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import java.io.File;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Unified music playback controller supporting Spotify Web API controls
 * (play, pause, next, prev, repeat/repeat_one, volume, mute, seek),
 * local saved audio playback (.wav/.au), and automatic LRCLIB synced lyrics lookup.
 */
public final class MusicPlaybackController {

    public enum MusicSource {
        SPOTIFY("Spotify"),
        YT_MUSIC("YT Music"),
        YOUTUBE("YouTube"),
        LOCAL("Saved Local");

        public final String displayName;
        MusicSource(String displayName) { this.displayName = displayName; }

        public static MusicSource fromId(String id) {
            if (id == null) return SPOTIFY;
            for (MusicSource s : values()) {
                if (s.name().equalsIgnoreCase(id)) return s;
            }
            return SPOTIFY;
        }
    }

    public enum RepeatMode {
        OFF("off"),
        ALL("context"),
        ONE("track");

        public final String spotifyState;
        RepeatMode(String spotifyState) { this.spotifyState = spotifyState; }
    }

    private static final MusicPlaybackController INSTANCE = new MusicPlaybackController();

    private volatile MusicSource activeSource = MusicSource.SPOTIFY;
    private volatile RepeatMode repeatMode = RepeatMode.OFF;
    private volatile boolean isMuted = false;
    private volatile int volumePercent = 80;
    private volatile int previousVolume = 80;

    private Clip localClip;
    private final List<File> savedTracks = new ArrayList<>();
    private int localTrackIndex = 0;
    private volatile boolean localPlaying = false;
    private volatile String localTitle = "";
    private volatile String localArtist = "Local Saved";
    private volatile long localDurationMs = 0;

    private final Set<String> fetchedLyricsKeys = ConcurrentHashMap.newKeySet();

    private MusicPlaybackController() {}

    public static MusicPlaybackController getInstance() {
        return INSTANCE;
    }

    public void initFromConfig() {
        activeSource = MusicSource.fromId(WynConfig.CONFIG.musicSource);
        volumePercent = Math.max(0, Math.min(100, WynConfig.CONFIG.musicVolume));
        reloadLocalTracks();
    }

    public synchronized void reloadLocalTracks() {
        savedTracks.clear();
        Path savedDir = FabricPaths.dir().resolve("saved");
        File folder = savedDir.toFile();
        if (!folder.exists()) {
            folder.mkdirs();
        }
        File[] files = folder.listFiles((dir, name) ->
                name.toLowerCase().endsWith(".wav") || name.toLowerCase().endsWith(".au"));
        if (files != null) {
            savedTracks.addAll(List.of(files));
        }
    }

    public void cycleSource() {
        MusicSource next = switch (activeSource) {
            case SPOTIFY -> MusicSource.YT_MUSIC;
            case YT_MUSIC -> MusicSource.YOUTUBE;
            case YOUTUBE -> MusicSource.LOCAL;
            case LOCAL -> MusicSource.SPOTIFY;
        };
        setActiveSource(next);
    }

    public void setActiveSource(MusicSource source) {
        if (source == null) return;
        if (this.activeSource == MusicSource.LOCAL && source != MusicSource.LOCAL) {
            stopLocalClip();
        }
        this.activeSource = source;
        WynConfig.CONFIG.musicSource = source.name();
        WynConfig.save();

        if (source == MusicSource.LOCAL) {
            reloadLocalTracks();
        } else {
            SpotifyClient.requestImmediatePoll();
        }
    }

    public void togglePlayPause() {
        if (activeSource == MusicSource.LOCAL) {
            toggleLocalPlayPause();
            return;
        }
        boolean currentlyPlaying = LrcPlayer.INSTANCE.isPlaying();
        String url = currentlyPlaying
                ? "https://api.spotify.com/v1/me/player/pause"
                : "https://api.spotify.com/v1/me/player/play";
        LrcPlayer.INSTANCE.setPlayingOptimistic(!currentlyPlaying);
        sendSpotifyCommand("PUT", url);
    }

    public void nextTrack() {
        if (activeSource == MusicSource.LOCAL) {
            playLocalOffset(1);
            return;
        }
        sendSpotifyCommand("POST", "https://api.spotify.com/v1/me/player/next");
    }

    public void previousTrack() {
        if (activeSource == MusicSource.LOCAL) {
            playLocalOffset(-1);
            return;
        }
        sendSpotifyCommand("POST", "https://api.spotify.com/v1/me/player/previous");
    }

    public void cycleRepeatMode() {
        repeatMode = switch (repeatMode) {
            case OFF -> RepeatMode.ALL;
            case ALL -> RepeatMode.ONE;
            case ONE -> RepeatMode.OFF;
        };

        if (activeSource == MusicSource.LOCAL) {
            if (localClip != null) {
                localClip.loop(repeatMode == RepeatMode.ONE ? Clip.LOOP_CONTINUOUSLY : 0);
            }
            return;
        }
        sendSpotifyCommand("PUT", "https://api.spotify.com/v1/me/player/repeat?state=" + repeatMode.spotifyState);
    }

    public void setVolume(int percent) {
        this.volumePercent = Math.max(0, Math.min(100, percent));
        this.isMuted = (this.volumePercent == 0);
        if (!this.isMuted) {
            this.previousVolume = this.volumePercent;
        }
        WynConfig.CONFIG.musicVolume = this.volumePercent;

        if (activeSource == MusicSource.LOCAL) {
            applyLocalVolume();
            return;
        }
        sendSpotifyCommand("PUT", "https://api.spotify.com/v1/me/player/volume?volume_percent=" + this.volumePercent);
    }

    public void toggleMute() {
        if (isMuted) {
            setVolume(previousVolume > 0 ? previousVolume : 50);
        } else {
            previousVolume = volumePercent > 0 ? volumePercent : 50;
            setVolume(0);
        }
    }

    public void seekTo(long targetMs) {
        long clamped = Math.max(0, Math.min(getDurationMs(), targetMs));
        if (activeSource == MusicSource.LOCAL) {
            if (localClip != null) {
                localClip.setMicrosecondPosition(clamped * 1000L);
            }
            return;
        }
        LrcPlayer.INSTANCE.seekOptimistic(clamped);
        sendSpotifyCommand("PUT", "https://api.spotify.com/v1/me/player/seek?position_ms=" + clamped);
    }

    private void sendSpotifyCommand(String method, String url) {
        Thread t = new Thread(() -> {
            try {
                String token = SpotifyAuth.validToken();
                if (token == null) {
                    String legacy = WynConfig.CONFIG.spotifyAccessToken;
                    if (legacy != null && !legacy.isBlank()) token = legacy.trim();
                }
                if (token == null || token.isBlank()) return;

                Http.Response res = Http.sendEmpty(method, url, Map.of("Authorization", "Bearer " + token), 6000);
                if (res.code() == 401) {
                    SpotifyAuth.invalidateAccess();
                } else if (res.code() >= 400) {
                    WynLyricsClient.LOGGER.warn("Spotify player command {} {} returned HTTP {}", method, url, res.code());
                }
                SpotifyClient.requestImmediatePoll();
            } catch (Exception e) {
                WynLyricsClient.LOGGER.warn("Spotify player command failed: {}", e.getMessage());
            }
        }, "WynLyrics-SpotifyCmd");
        t.setDaemon(true);
        t.start();
    }

    public void syncRepeatFromSpotify(String state) {
        if (state == null) return;
        repeatMode = switch (state.toLowerCase()) {
            case "track" -> RepeatMode.ONE;
            case "context" -> RepeatMode.ALL;
            default -> RepeatMode.OFF;
        };
    }

    public void syncVolumeFromSpotify(int vol) {
        if (vol >= 0 && vol <= 100) {
            this.volumePercent = vol;
            this.isMuted = (vol == 0);
            if (!this.isMuted) this.previousVolume = vol;
        }
    }

    private synchronized void toggleLocalPlayPause() {
        try {
            if (localClip == null) {
                if (savedTracks.isEmpty()) reloadLocalTracks();
                if (!savedTracks.isEmpty()) playLocalFile(savedTracks.get(localTrackIndex));
                return;
            }
            if (localClip.isRunning()) {
                localClip.stop();
                localPlaying = false;
            } else {
                localClip.start();
                localPlaying = true;
            }
        } catch (Exception e) {
            WynLyricsClient.LOGGER.warn("Local audio toggle failed: {}", e.getMessage());
        }
    }

    private synchronized void playLocalOffset(int offset) {
        if (savedTracks.isEmpty()) reloadLocalTracks();
        if (savedTracks.isEmpty()) return;
        localTrackIndex = Math.floorMod(localTrackIndex + offset, savedTracks.size());
        playLocalFile(savedTracks.get(localTrackIndex));
    }

    private synchronized void playLocalFile(File file) {
        try {
            stopLocalClip();
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(file);
            localClip = AudioSystem.getClip();
            localClip.open(audioIn);
            applyLocalVolume();
            if (repeatMode == RepeatMode.ONE) {
                localClip.loop(Clip.LOOP_CONTINUOUSLY);
            } else {
                localClip.start();
            }
            localTitle = file.getName().replaceFirst("[.][^.]+$", "");
            localArtist = "Local Saved";
            localDurationMs = Math.max(1L, localClip.getMicrosecondLength() / 1000L);
            localPlaying = true;
            LrcPlayer.INSTANCE.loadLocalTrackLyrics(localTitle);
        } catch (Exception e) {
            WynLyricsClient.LOGGER.warn("Could not play local audio {}: {}", file.getName(), e.getMessage());
        }
    }

    private synchronized void stopLocalClip() {
        if (localClip != null) {
            try {
                localClip.stop();
                localClip.close();
            } catch (Exception ignored) {}
            localClip = null;
        }
        localPlaying = false;
    }

    private void applyLocalVolume() {
        if (localClip != null && localClip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            FloatControl gain = (FloatControl) localClip.getControl(FloatControl.Type.MASTER_GAIN);
            float dB = (volumePercent == 0)
                    ? gain.getMinimum()
                    : (float) (Math.log10(volumePercent / 100.0) * 20.0);
            gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), dB)));
        }
    }

    public void autoFetchLyricsIfMissing(String title, String artist) {
        if (!WynConfig.CONFIG.autoFetchLyrics || title == null || title.isBlank()) return;
        String key = (artist + " - " + title).toLowerCase();
        if (!fetchedLyricsKeys.add(key)) return;

        Thread t = new Thread(() -> {
            try {
                String qTrack = URLEncoder.encode(title, StandardCharsets.UTF_8);
                String qArtist = URLEncoder.encode(artist == null ? "" : artist, StandardCharsets.UTF_8);
                String url = "https://lrclib.net/api/get?track_name=" + qTrack + "&artist_name=" + qArtist;
                Http.Response res = Http.get(url, Map.of(), 7000);
                if (res.code() == 200 && res.body() != null && !res.body().isBlank()) {
                    JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
                    if (json.has("syncedLyrics") && !json.get("syncedLyrics").isJsonNull()) {
                        String lrc = json.get("syncedLyrics").getAsString();
                        if (!lrc.isBlank()) {
                            String baseName = (artist != null && !artist.isBlank())
                                    ? artist + " - " + title
                                    : title;
                            Path target = FabricPaths.resolveLrc(baseName);
                            if (target != null) {
                                Files.createDirectories(target.getParent());
                                Files.writeString(target, lrc, StandardCharsets.UTF_8);
                                LrcPlayer.INSTANCE.reload();
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}
        }, "WynLyrics-LrclibFetch");
        t.setDaemon(true);
        t.start();
    }

    public MusicSource getActiveSource() { return activeSource; }
    public RepeatMode getRepeatMode() { return repeatMode; }
    public boolean isMuted() { return isMuted; }
    public int getVolumePercent() { return volumePercent; }
    public int getSavedTrackCount() { return savedTracks.size(); }

    public boolean isPlaying() {
        return activeSource == MusicSource.LOCAL ? localPlaying : LrcPlayer.INSTANCE.isPlaying();
    }

    public String getCurrentTitle() {
        if (activeSource == MusicSource.LOCAL) {
            return localTitle.isEmpty() ? "No local track (" + savedTracks.size() + " files)" : localTitle;
        }
        String t = LrcPlayer.INSTANCE.title();
        return t.isEmpty() ? "No active track" : t;
    }

    public String getCurrentArtist() {
        if (activeSource == MusicSource.LOCAL) {
            return localTitle.isEmpty() ? "Put .wav files in config/wynlyrics/saved" : localArtist;
        }
        String a = LrcPlayer.INSTANCE.artist();
        return a.isEmpty() ? activeSource.displayName : a;
    }

    public long getProgressMs() {
        if (activeSource == MusicSource.LOCAL) {
            return localClip != null ? Math.max(0L, localClip.getMicrosecondPosition() / 1000L) : 0L;
        }
        return LrcPlayer.INSTANCE.positionMs();
    }

    public long getDurationMs() {
        if (activeSource == MusicSource.LOCAL) {
            return Math.max(1L, localDurationMs);
        }
        return Math.max(1L, LrcPlayer.INSTANCE.durationMs());
    }
}
