package com.wynlyrics.ui;

import com.wynlyrics.config.ThemePreset;
import com.wynlyrics.config.WynConfig;
import com.wynlyrics.config.WynConfig.Config;
import com.wynlyrics.lyrics.LyricView;
import com.wynlyrics.lyrics.SampleSource;
import com.wynlyrics.render.FontRegistry;
import com.wynlyrics.render.HudRenderer;
import com.wynlyrics.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Live-preview editor for themes, colors, effects and fonts. */
public final class CosmeticEditorScreen extends Screen {
    private enum Tab { THEMES, COLORS, EFFECTS, FONT }
    private enum Target { TEXT, ACCENT, INACTIVE, BACKGROUND, BORDER, PROGRESS, OUTLINE }

    private static Tab tab = Tab.THEMES;
    private static Target target = Target.TEXT;

    private final Screen parent;
    private final LyricView preview = new LyricView(new SampleSource(new String[]{
            I18n.translate("wynlyrics.sample.1"), I18n.translate("wynlyrics.sample.2"), I18n.translate("wynlyrics.sample.3")}));
    private final List<ConfigSlider> rgb = new ArrayList<>();
    private TextFieldWidget hexField;
    private boolean updatingHex = false;
    private int previewBottom = 100;

    public CosmeticEditorScreen(Screen parent) {
        super(Text.translatable("wynlyrics.cosmetic.title"));
        this.parent = parent;
    }

    private static int get(Target t) {
        Config c = WynConfig.CONFIG;
        return switch (t) {
            case TEXT -> c.textColor; case ACCENT -> c.accentColor; case INACTIVE -> c.inactiveColor;
            case BACKGROUND -> c.backgroundColor; case BORDER -> c.borderColor;
            case PROGRESS -> c.progressColor; case OUTLINE -> c.outlineColor;
        };
    }

    private static void set(Target t, int v) {
        Config c = WynConfig.CONFIG;
        v &= 0xFFFFFF;
        switch (t) {
            case TEXT -> c.textColor = v; case ACCENT -> c.accentColor = v; case INACTIVE -> c.inactiveColor = v;
            case BACKGROUND -> c.backgroundColor = v; case BORDER -> c.borderColor = v;
            case PROGRESS -> c.progressColor = v; case OUTLINE -> c.outlineColor = v;
        }
        c.theme = "custom";
    }

    @Override
    protected void init() {
        HudRenderer.editing = true;
        FontRegistry.refresh();
        rgb.clear();
        Config c = WynConfig.CONFIG;
        int cx = width / 2, x0 = cx - 156;

        previewBottom = 14 + Math.round(HudRenderer.boxHeight(preview.source()) * 1f) + 6;
        int ty = previewBottom;

        Tab[] tabs = Tab.values();
        int tw = 76;
        for (int i = 0; i < tabs.length; i++) {
            Tab tb = tabs[i];
            ButtonWidget b = Ui.button(x0 + i * (tw + 3), ty, tw, Text.translatable("wynlyrics.ctab." + tb.name().toLowerCase()), () -> {
                tab = tb;
                clearAndInit();
            });
            b.setHeight(18);
            b.active = tab != tb;
            addDrawableChild(b);
        }

        int top = ty + 24;
        switch (tab) {
            case THEMES -> {
                List<ThemePreset> all = ThemePreset.ALL;
                for (int i = 0; i < all.size(); i++) {
                    ThemePreset p = all.get(i);
                    ButtonWidget b = Ui.button(x0 + (i % 2) * 158, top + (i / 2) * 22, 154,
                            Text.translatable("wynlyrics.theme." + p.id()).copy().styled(s -> s.withColor(p.accent())), () -> {
                                c.applyTheme(p);
                                WynConfig.save();
                                clearAndInit();
                            });
                    b.active = !p.id().equals(c.theme);
                    addDrawableChild(b);
                }
            }
            case COLORS -> {
                addDrawableChild(Ui.button(x0, top, 312, Text.translatable("wynlyrics.copt.target")
                        .append(": ").append(Text.translatable("wynlyrics.color." + target.name().toLowerCase())), () -> {
                    target = Target.values()[(target.ordinal() + 1) % Target.values().length];
                    clearAndInit();
                }));
                String[] names = {"R", "G", "B"};
                int[] shifts = {16, 8, 0};
                for (int i = 0; i < 3; i++) {
                    final int sh = shifts[i];
                    final String nm = names[i];
                    ConfigSlider s = new ConfigSlider(x0 + i * 105, top + 24, 102, 20, 0, 255, 1,
                            () -> (get(target) >> sh) & 255,
                            v -> {
                                int cur = get(target);
                                set(target, (cur & ~(255 << sh)) | ((int) v << sh));
                                refreshHex();
                            },
                            v -> Text.literal(nm + ": " + (int) v), null);
                    rgb.add(s);
                    addDrawableChild(s);
                }
                hexField = new TextFieldWidget(textRenderer, x0 + 22, top + 48, 80, 20, Text.literal("hex"));
                hexField.setMaxLength(7);
                hexField.setText(ColorUtil.hex(get(target)));
                hexField.setChangedListener(s -> {
                    if (updatingHex) return;
                    int v = ColorUtil.parseHex(s);
                    if (v >= 0) {
                        set(target, v);
                        for (ConfigSlider sl : rgb) sl.sync();
                    }
                });
                addDrawableChild(hexField);
                addDrawableChild(new ConfigSlider(x0 + 105, top + 48, 207, 20, 0, 1, 0.05, () -> c.backgroundOpacity, v -> c.backgroundOpacity = (float) v,
                        v -> Ui.labeled("wynlyrics.he.opacity", (int) Math.round(v * 100) + "%"), null));
            }
            case EFFECTS -> {
                addDrawableChild(Ui.toggle(x0, top, 154, "wynlyrics.copt.shadow", () -> c.textShadow, v -> c.textShadow = v));
                addDrawableChild(Ui.toggle(x0 + 158, top, 154, "wynlyrics.copt.outline", () -> c.textOutline, v -> c.textOutline = v));
                addDrawableChild(Ui.toggle(x0, top + 24, 154, "wynlyrics.copt.glow", () -> c.textGlow, v -> c.textGlow = v));
                addDrawableChild(new ConfigSlider(x0 + 158, top + 24, 154, 20, 0.1, 1, 0.05, () -> c.inactiveOpacity, v -> c.inactiveOpacity = (float) v,
                        v -> Ui.labeled("wynlyrics.copt.inactive", (int) Math.round(v * 100) + "%"), null));
                addDrawableChild(new ConfigSlider(x0, top + 48, 154, 20, 0, 8, 1, () -> c.cornerRadius, v -> c.cornerRadius = (int) v,
                        v -> Ui.labeled("wynlyrics.copt.radius", String.valueOf((int) v)), null));
                addDrawableChild(new ConfigSlider(x0 + 158, top + 48, 154, 20, 0, 3, 1, () -> c.borderThickness, v -> c.borderThickness = (int) v,
                        v -> Ui.labeled("wynlyrics.copt.border", String.valueOf((int) v)), null));
            }
            case FONT -> {
                List<FontRegistry.Entry> fonts = FontRegistry.available();
                for (int i = 0; i < fonts.size(); i++) {
                    FontRegistry.Entry e = fonts.get(i);
                    boolean sel = e.id().equals(c.fontId);
                    Text label = FontRegistry.text(e.label(), e.id()).copy().formatted(sel ? Formatting.GREEN : Formatting.WHITE);
                    ButtonWidget b = Ui.button(x0 + (i % 2) * 158, top + (i / 2) * 22, 154, label, () -> {
                        c.fontId = e.id();
                        WynConfig.save();
                        clearAndInit();
                    });
                    addDrawableChild(b);
                }
            }
        }

        addDrawableChild(Ui.button(cx - 50, height - 24, 100, Text.translatable("wynlyrics.opt.done"), this::close));
    }

    private void refreshHex() {
        if (hexField == null) return;
        updatingHex = true;
        hexField.setText(ColorUtil.hex(get(target)));
        updatingHex = false;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xAA000000);
        Config c = WynConfig.CONFIG;
        int w = Math.min(c.hudWidth, 312);
        HudRenderer.draw(ctx, textRenderer, preview, width / 2, 14, 1f, w, 1f);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 3, 0x55D6FF);
        if (tab == Tab.COLORS && hexField != null) {
            int top = previewBottom + 24;
            ctx.fill(width / 2 - 156, top + 48, width / 2 - 156 + 18, top + 68, 0xFF000000 | get(target));
            ctx.drawBorder(width / 2 - 156, top + 48, 18, 20, 0xFFFFFFFF);
        }
    }

    @Override
    public void removed() {
        HudRenderer.editing = false;
        WynConfig.save();
    }

    @Override
    public void close() { if (client != null) client.setScreen(parent); }
}
