package com.wynlyrics.ui;

import com.wynlyrics.config.WynConfig;
import com.wynlyrics.config.WynConfig.Config;
import com.wynlyrics.lyrics.LyricView;
import com.wynlyrics.lyrics.SampleSource;
import com.wynlyrics.render.HudRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Drag the lyric box with the mouse, scroll to scale, use the panel for width,
 * opacity and alignment. Press H to hide/show the panel, arrow keys nudge.
 */
public final class HudEditorScreen extends Screen {
    private final Screen parent;
    private final LyricView preview = new LyricView(new SampleSource(new String[]{
            I18n.translate("wynlyrics.sample.1"), I18n.translate("wynlyrics.sample.2"), I18n.translate("wynlyrics.sample.3")}));
    private final List<ClickableWidget> panel = new ArrayList<>();
    private final List<ConfigSlider> sliders = new ArrayList<>();
    private boolean panelVisible = true;
    private boolean dragging = false;
    private boolean snapped = false;
    private double dragDx, dragDy;

    public HudEditorScreen(Screen parent) {
        super(Text.translatable("wynlyrics.hudeditor.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        HudRenderer.editing = true;
        panel.clear();
        sliders.clear();
        Config c = WynConfig.CONFIG;
        int cx = width / 2, w3 = 102, x0 = cx - 156;

        ConfigSlider scale = new ConfigSlider(x0, 6, w3, 20, 0.5, 3.0, 0.05, () -> c.hudScale, v -> c.hudScale = (float) v,
                v -> Ui.labeled("wynlyrics.he.scale", Ui.f(v, 2) + "x"), null);
        ConfigSlider widthS = new ConfigSlider(x0 + 105, 6, w3, 20, 140, 520, 10, () -> c.hudWidth, v -> c.hudWidth = (int) v,
                v -> Ui.labeled("wynlyrics.he.width", String.valueOf((int) v)), null);
        ConfigSlider opacity = new ConfigSlider(x0 + 210, 6, w3, 20, 0, 1, 0.05, () -> c.backgroundOpacity, v -> c.backgroundOpacity = (float) v,
                v -> Ui.labeled("wynlyrics.he.opacity", (int) Math.round(v * 100) + "%"), null);
        sliders.add(scale); sliders.add(widthS); sliders.add(opacity);
        panel.add(scale); panel.add(widthS); panel.add(opacity);

        panel.add(Ui.cycle(x0, 30, 77, "wynlyrics.he.align", List.of("left", "center", "right"), () -> c.alignment, v -> c.alignment = v,
                v -> Text.translatable("wynlyrics.align." + v)));
        panel.add(Ui.button(x0 + 79, 30, 77, Text.translatable("wynlyrics.he.center"), () -> {
            c.hudX = 0.5f;
            WynConfig.save();
        }));
        panel.add(Ui.button(x0 + 158, 30, 77, Text.translatable("wynlyrics.he.reset"), () -> {
            Config d = new Config();
            c.hudX = d.hudX; c.hudY = d.hudY; c.hudScale = d.hudScale; c.hudWidth = d.hudWidth;
            c.alignment = d.alignment; c.backgroundOpacity = d.backgroundOpacity;
            WynConfig.save();
            clearAndInit();
        }));
        panel.add(Ui.button(x0 + 237, 30, 75, Text.translatable("wynlyrics.opt.done"), this::close));

        for (ClickableWidget wdg : panel) { wdg.visible = panelVisible; addDrawableChild(wdg); }
    }

    private void syncSliders() { for (ConfigSlider s : sliders) s.sync(); }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x55000000);
        Config c = WynConfig.CONFIG;
        if (snapped) ctx.fill(width / 2, 0, width / 2 + 1, height, 0x66FFFFFF);
        int[] b = HudRenderer.draw(ctx, textRenderer, preview, Math.round(c.hudX * width), Math.round(c.hudY * height),
                c.hudScale, c.hudWidth, 1f);
        ctx.drawBorder(b[0] - 2, b[1] - 2, b[2] + 4, b[3] + 4, dragging ? 0xFFFFD166 : 0xAA55D6FF);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable("wynlyrics.he.hint"), width / 2, height - 12, 0xCCCCCC);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        int[] b = HudRenderer.lastBounds;
        if (button == 0 && mx >= b[0] && mx <= b[0] + b[2] && my >= b[1] && my <= b[1] + b[3]) {
            dragging = true;
            dragDx = mx - b[0];
            dragDy = my - b[1];
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            Config c = WynConfig.CONFIG;
            int[] b = HudRenderer.lastBounds;
            double center = mx - dragDx + b[2] / 2.0;
            snapped = Math.abs(center - width / 2.0) < 6;
            if (snapped) center = width / 2.0;
            c.hudX = (float) Math.max(0, Math.min(1, center / width));
            c.hudY = (float) Math.max(0, Math.min(1, (my - dragDy) / height));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging) {
            dragging = false;
            snapped = false;
            WynConfig.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        int[] b = HudRenderer.lastBounds;
        if (mx >= b[0] && mx <= b[0] + b[2] && my >= b[1] && my <= b[1] + b[3]) {
            Config c = WynConfig.CONFIG;
            c.hudScale = Math.max(0.5f, Math.min(3f, c.hudScale + (float) vAmount * 0.05f));
            syncSliders();
            WynConfig.save();
            return true;
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        Config c = WynConfig.CONFIG;
        boolean typing = getFocused() != null && getFocused() instanceof net.minecraft.client.gui.widget.TextFieldWidget;
        if (!typing) {
            if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_H) {
                panelVisible = !panelVisible;
                for (ClickableWidget w : panel) w.visible = panelVisible;
                return true;
            }
            float stepX = 1f / width, stepY = 1f / height;
            boolean arrow = true;
            switch (key) {
                case org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT -> c.hudX -= stepX;
                case org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT -> c.hudX += stepX;
                case org.lwjgl.glfw.GLFW.GLFW_KEY_UP -> c.hudY -= stepY;
                case org.lwjgl.glfw.GLFW.GLFW_KEY_DOWN -> c.hudY += stepY;
                default -> arrow = false;
            }
            if (arrow) {
                c.hudX = Math.max(0, Math.min(1, c.hudX));
                c.hudY = Math.max(0, Math.min(1, c.hudY));
                return true;
            }
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void removed() {
        HudRenderer.editing = false;
        WynConfig.save();
    }

    @Override
    public void close() { if (client != null) client.setScreen(parent); }
}
