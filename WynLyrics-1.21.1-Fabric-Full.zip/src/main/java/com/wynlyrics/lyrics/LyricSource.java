package com.wynlyrics.lyrics;

/** Anything that can feed the lyric renderers (live player or editor sample). */
public interface LyricSource {
    String title();
    String artist();
    long durationMs();
    long positionMs();
    int lineCount();
    String lineText(int index);
    /** Index of the active line, or -1 before the first line. */
    int currentIndex();
    /** 0..1 progress through the given line (used for karaoke fill). */
    float lineProgress(int index);
    boolean hasLyrics();
    /** Lang key shown when there are no lyrics, or "" when lyrics exist. */
    String statusKey();
}
