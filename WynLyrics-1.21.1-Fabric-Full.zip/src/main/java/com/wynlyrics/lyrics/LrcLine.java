package com.wynlyrics.lyrics;

public record LrcLine(long timeMs, String text) {}
