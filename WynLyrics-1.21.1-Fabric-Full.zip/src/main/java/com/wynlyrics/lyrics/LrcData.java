package com.wynlyrics.lyrics;

import java.util.List;

/** Parsed LRC file. offsetMs follows the LRC spec: positive = lyrics appear sooner. */
public record LrcData(List<LrcLine> lines, long offsetMs, String title, String artist) {
    public static final LrcData EMPTY = new LrcData(List.of(), 0, "", "");
}
