package com.wynlyrics.lyrics;

import com.wynlyrics.util.Easing;

import java.util.ArrayList;
import java.util.List;

/**
 * Turns a LyricSource + animation settings into a list of drawable items.
 * Pure logic (no Minecraft types) so both the HUD and the 3D renderer share it.
 */
public final class LyricView {
    public record Params(int before, int after, String anim, int animMs, float inactiveOpacity,
                         boolean lineFill, int textRgb, int inactiveRgb) {}

    /** slot: 0 = current line, -1 = one line above, +1 = one line below (fractional while animating). */
    public record Item(String text, float slot, float scale, float alpha, int rgb, float fill, boolean current) {}

    private final LyricSource src;
    private int lastIndex = Integer.MIN_VALUE;
    private int prevIndex = Integer.MIN_VALUE;
    private long changeAt;
    private String lastTrack = null;

    public LyricView(LyricSource src) { this.src = src; }

    public LyricSource source() { return src; }

    public List<Item> compute(Params p, long now) {
        int count = src.lineCount();
        int cur = src.currentIndex();
        String key = src.title() + "\u0000" + src.artist() + "\u0000" + count;
        if (!key.equals(lastTrack)) {
            lastTrack = key; lastIndex = cur; prevIndex = Integer.MIN_VALUE; changeAt = now - 1_000_000L;
        } else if (cur != lastIndex) {
            prevIndex = lastIndex; lastIndex = cur; changeAt = now;
        }

        String anim = p.anim() == null ? "slide" : p.anim();
        boolean none = anim.equals("none") || p.animMs() <= 0;
        boolean slide = !none && anim.equals("slide");
        boolean zoom = !none && anim.equals("zoom");
        boolean type = !none && anim.equals("typewriter");

        float e = none ? 1f : Easing.clamp01((now - changeAt) / (float) p.animMs());
        float eased = Easing.outCubic(e);
        int dir = (prevIndex == Integer.MIN_VALUE || cur >= prevIndex) ? 1 : -1;

        List<Item> out = new ArrayList<>();
        if (count == 0) return out;

        if (cur < 0) {
            out.add(new Item("\u266A", 0f, 1f, 1f, p.textRgb(), -1f, true));
        }

        for (int i = cur - p.before() - 1; i <= cur + p.after() + 1; i++) {
            if (i < 0 || i >= count) continue;
            String text = src.lineText(i);
            boolean blank = text == null || text.isBlank();
            if (blank) text = "\u266A";

            float slotBase = i - cur;
            float slot = slide ? slotBase + (1f - eased) * dir : slotBase;

            float w;
            if (slide) w = Easing.clamp01(1f - Math.abs(slot));
            else if (i == cur) w = eased;
            else if (i == prevIndex && e < 1f) w = 1f - eased;
            else w = 0f;

            float edge = slot < 0
                    ? Easing.clamp01(p.before() + 1 + slot)
                    : Easing.clamp01(p.after() + 1 - slot);
            if (!slide && i == prevIndex && e < 1f) edge = Math.max(edge, 1f - eased);
            if (cur < 0 && i == 0) edge = Math.max(edge, 1f); // keep the upcoming first line visible

            float alpha = edge * Easing.lerp(p.inactiveOpacity(), 1f, w);
            float scale = Easing.lerp(0.82f, 1f, w);
            if (zoom && i == cur) scale *= Easing.lerp(0.7f, 1f, Easing.outBack(e));
            int rgb = com.wynlyrics.util.ColorUtil.lerpRgb(p.inactiveRgb(), p.textRgb(), w);

            float fill = -1f;
            if (i == cur && p.lineFill() && !blank) fill = src.lineProgress(i);

            if (type && i == cur && !blank) {
                float rv = Easing.clamp01((now - changeAt) / (float) (p.animMs() * 3L));
                int cps = text.codePointCount(0, text.length());
                int n = (int) Math.ceil(cps * rv);
                text = text.substring(0, text.offsetByCodePoints(0, Math.min(n, cps)));
                if (rv < 1f) fill = -1f;
            }
            out.add(new Item(text, slot, scale, alpha, rgb, fill, i == cur));
        }
        return out;
    }
}
