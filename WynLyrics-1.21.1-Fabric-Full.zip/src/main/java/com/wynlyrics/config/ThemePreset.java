package com.wynlyrics.config;

import java.util.List;

public record ThemePreset(String id, int text, int accent, int inactive, int bg, int border,
                          int progress, int track, float bgOpacity) {
    public static final List<ThemePreset> ALL = List.of(
            new ThemePreset("dark",   0xFFFFFF, 0x55D6FF, 0x9AA0AA, 0x10131B, 0x55D6FF, 0x55D6FF, 0x444A55, 0.55f),
            new ThemePreset("light",  0x1B1F2A, 0x0B7BD6, 0x6B7280, 0xF4F6FA, 0x0B7BD6, 0x0B7BD6, 0xC9CEDA, 0.80f),
            new ThemePreset("neon",   0xF8F8FF, 0xFF2BD6, 0x7A5C9E, 0x0A0014, 0x00F0FF, 0xFF2BD6, 0x3A1E5C, 0.70f),
            new ThemePreset("sunset", 0xFFF4E6, 0xFF8A3D, 0xC98F7A, 0x2A0F1E, 0xFF5E78, 0xFFB347, 0x5A2A3A, 0.65f),
            new ThemePreset("mint",   0xF0FFF8, 0x3DDC97, 0x8FB8A8, 0x0E2220, 0x3DDC97, 0x3DDC97, 0x2D4A44, 0.60f),
            new ThemePreset("rose",   0xFFF0F5, 0xFF6FA5, 0xC9A0B2, 0x2B1020, 0xFF6FA5, 0xFF6FA5, 0x5A2C45, 0.60f),
            new ThemePreset("mono",   0xFFFFFF, 0xD0D0D0, 0x808080, 0x000000, 0x606060, 0xFFFFFF, 0x404040, 0.50f)
    );

    public static ThemePreset byId(String id) {
        for (ThemePreset p : ALL) if (p.id.equals(id)) return p;
        return ALL.get(0);
    }
}
